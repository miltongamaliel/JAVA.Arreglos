package com.mgCoding.JAVA.Arreglos_y_arreglos_con_objetos;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* 
		 * El siguiente arreglo, en cada item acepta un objeto de tipo clase determinada.
		 */
		Alumnos arreglo1[] = new Alumnos[2];
		arreglo1[0]= new Alumnos("Jess","Cardenas","Genero",0);
		System.out.println(arreglo1[0].getApellidos());
		/*
		 * Esta es una segunda forma para crear un arreglo, no se establece implicitamente el tamano
		 * pero si por medio de los datos cargados entre "{}". Notese que el valor int (edad) debio car
		 * garse como un string ya que si no es objeto, acepta datos solo de un tipo
		 */
		
		String[] arreglo2 = {"Mel","Zuniga","Mujer","17"};
		System.out.println(arreglo2[1]);
		
		/*
		 * En ocaciones es necesario pasar un arraylist o un list a un arreglo. Esto porque algunos metodos
		 * de objetos como JOptionPaneInputMessage en su sobrecarga de 6 atributos que incluye un ComboBox.
		 */
		ArrayList<Alumnos> arregloArrayList1 = new ArrayList<>();
		arregloArrayList1.add(new Alumnos("Ana","Magallanes","Mujer",20));
		arregloArrayList1.add(new Alumnos("Katya","Hernandez","Mujer",16));
		Object arregloCadena1[] = new Object[arregloArrayList1.size()];
		
		// En la clase alumnos se sobrescribe el metodo toString para imprimir en pantalla el valor
		// de arregloCadena1
		for (int i = 0 ; i< arregloArrayList1.size();i++) {
			arregloCadena1[i] = arregloArrayList1.get(i);
			System.out.println(arregloCadena1[i].toString());
		}		
		
		/*
		 * Puedo  crear un ArrayList o un list de objetos, como se muestra.
		 */
		ArrayList<Alumnos> arregloArrayList2 = new ArrayList<>();
		arregloArrayList2.add(new Alumnos(null, null, null, 0));
		
		List<Alumnos> arregloList1 = new ArrayList<>();
		arregloList1.add(new Alumnos(null, null, null, 0));
		
		/*
		 * Para accesar al contenido de estos objetos, al guardar un objeto de arreglos, puedo accesar a cada
		 * parametro de forma independiente. Tambien puedo editarlos: 
		 */
		System.out.println(arregloArrayList2.get(0).getEdad());
		System.out.println(arregloList1.get(0).getApellidos());
		arregloArrayList2.get(0).setApellidos("Alonzo");
		
	}

}
