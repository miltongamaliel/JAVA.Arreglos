package com.mgCoding.JAVA.Arreglos_y_arreglos_con_objetos;

public class Alumnos {
	private String nombre, apellidos, genero;
	private int edad;
	public Alumnos(String nombre, String apellidos, String genero, int edad) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.genero = genero;
		this.edad = edad;
	}
	
	@Override
	public String toString() {
		return "Alumnos [nombre=" + nombre + ", apellidos=" + apellidos + ", genero=" + genero + ", edad=" + edad + "]";
	}

	// Getters y setters de la clase
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
}
